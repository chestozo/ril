;(function($) {
  var KEY_SETTINGS = 'settings'

  var Options = function() {}

  Options.prototype.init = function() {
    this.$user = $('.js-user')
    this.$save = $('.js-save').bind('click', this.save.bind(this))
    $(document).ready(this.firstTimeLoad.bind(this))
    return this
  }

  Options.prototype.firstTimeLoad = function() {
    this.getSettings((settings) => {
      this.$user.val(settings.user || '')
    })
  }

  Options.prototype.save = function() {
    this.getSettings((settings) => {
      settings.user = this.$user.val()
      this.saveSettings(settings)

      this.$save.attr('disabled', 'disabled')

      // Enable after text change.
      this.$user.one(
        'keydown',
        function() {
          this.$save.removeAttr('disabled')
        }.bind(this)
      )
    })
  }

  Options.prototype.saveSettings = function(settings) {
    chrome.storage.local.set({ [KEY_SETTINGS]: settings })
  }

  Options.prototype.getSettings = function(callback) {
    chrome.storage.local.get([KEY_SETTINGS], (result) =>
      callback(result[KEY_SETTINGS] || {})
    )
  }

  // Main.
  new Options().init()
})(jQuery)
