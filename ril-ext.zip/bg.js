/*global alert: false, chrome: false, console: false */
;(function() {
  var KEY_SETTINGS = 'settings'
  var MAX_GIF_SIZE = 5

  var tabs = {}

  /// Config.

  var config = {
    hosts: {
      // _default: 'http://localhost:3000', // test locally

      // _default: 'http://ril.chestozo.nodejitsu.com',           // nodejitsu: no free plans anymore (?)
      // _default: 'http://hidden-brushlands-8235.herokuapp.com', // heroku: sleep mode drops all cache files
      // _default: 'http://ril.eu01.aws.af.cm',                   // appfog: no free plans anymore starting - december 2015
      // _default: 'https://radiant-inlet-6073.herokuapp.com',    // heroku: tried again - sleep mode drops cache files - december 2015
      // _default: 'http://ril-chestozo.rhcloud.com',               // openshift.redhat.com: let's try this one - 28 december 2015
      // _default: 'http://ril-ril.193b.starter-ca-central-1.openshiftapps.com', // openshift v 3 - updated 12.10.2017
      // _default: 'http://ril-server-ril.7e14.starter-us-west-2.openshiftapps.com', // openshift v 3 - updated 19.01.2018
      _default: 'https://powerful-shore-53642.herokuapp.com', // heroku for now .. 17.05.2019

      // intranet: 'http://ril.verstka-photo.yandex.ru' // Intranet pages go here
      intranet: 'http://mailfront4.yandex.net:8087', // Intranet pages go here
    },
  }

  /// Helper funcs.

  var s = {
    has: function(str, substr) {
      return str.indexOf(substr) >= 0
    },
  }

  var getCanvasSize = function(w, h) {
    var max = 1136 // iphone 5 screen height
    // NOTE вписываем ширину (чтобы влезали высокие картинки)
    var max_side = w // w > h ? w : h;
    var scale = max_side > max ? max_side / max : 1
    return [Math.floor(w / scale), Math.floor(h / scale)]
  }

  var getSettings = function(callback) {
    chrome.storage.local.get([KEY_SETTINGS], (result) => {
      settings = result[KEY_SETTINGS]

      if (!settings) {
        alert('Please setup your extension')
        throw new Error('settings are not set')
      }

      callback(settings)
    })
  }

  // NOTE Instapaper does not support, but ril — yes, it does ;)

  /**
   * Generates unique url by appending nc parameter to it.
   * Used to aviod browser caching.
   * @param {String} url Base url.
   * @return {String} Unique url.
   */
  var noCacheUrl = function(url) {
    if (url.indexOf('?', url.lastIndexOf('/')) > -1) {
      url += '&nc=' + Date.now()
    } else {
      url += '?nc=' + Date.now()
    }
    return url
  }

  /**
   * Async method for getting MIME type for specified url.
   * @param {String} src File url.
   * @param {function(?mimeType:string, error=:Object)} doneCallback Result callback.
   */
  var getMimeType = function(src, doneCallback) {
    var xhr = new XMLHttpRequest()
    xhr.open('HEAD', noCacheUrl(src))

    xhr.onload = function() {
      doneCallback(xhr.getResponseHeader('Content-Type'))
    }

    xhr.onabort = function() {
      doneCallback(null, 'getMimeType error: aborted')
    }

    xhr.onerror = function() {
      doneCallback(null, 'getMimeType error: error')
    }

    xhr.ontimeout = function() {
      doneCallback(null, 'getMimeType error: timeout')
    }

    xhr.send()
  }

  /**
   * Async method for converting static image to base64 string.
   * @param {String} src File url.
   * @param {function(?base64:string, error=:Object)} doneCallback Result callback.
   */
  var staticImage2Base64 = function(src, doneCallback) {
    var i = new Image()

    i.onload = function() {
      try {
        // Create an empty canvas element
        var canvas = document.createElement('canvas')
        var size = getCanvasSize(i.width, i.height)
        canvas.width = size[0]
        canvas.height = size[1]

        // Draw image scaled.
        var ctx = canvas.getContext('2d')

        // Fill with white.
        ctx.fillStyle = 'rgb(255,255,255)'
        ctx.fillRect(0, 0, canvas.width, canvas.height)

        // Draw image.
        ctx.drawImage(i, 0, 0, canvas.width, canvas.height)

        // Get the data-URL formatted image
        // Firefox supports PNG and JPEG. You could check img.src to
        // guess the original format, but be aware the using "image/jpg"
        // will re-encode the image.

        /** NOTE png is too big
                For same image we get (bytes):
                1066322 image/png
                 415579 image/jpeg 1.0 quality
                 183015 image/jpeg default quality
                 174311 image/jpeg 0.9 quality
            */
        // var code = canvas.toDataURL("image/jpeg");
        // WARNING не поддерживается в ios safari http://caniuse.com/webp
        // var code = canvas.toDataURL("image/webp");
        var code = canvas.toDataURL('image/jpeg', 0.7)

        // NOTE это для тестирования других размеров и качеств.
        // Пока выбрал webp: оно в среднем в 2 раза меньше jpeg и выглядит ничего.
        // var test = [
        //     { mime: 'image/jpeg' },
        //     { mime: 'image/jpeg', q: 1 },
        //     { mime: 'image/jpeg', q: 0.95 },
        //     { mime: 'image/jpeg', q: 0.90 },
        //     { mime: 'image/jpeg', q: 0.85 },
        //     { mime: 'image/jpeg', q: 0.80 },
        //     { mime: 'image/jpeg', q: 0.75 },
        //     { mime: 'image/jpeg', q: 0.70 },
        //     { mime: 'image/jpeg', q: 0.65 },
        //     { mime: 'image/jpeg', q: 0.60 },
        //     { mime: 'image/webp' }
        // ];

        // for (var j = 0; j < test.length; j++) {
        //     var code = canvas.toDataURL(test[j].mime, test[j].q);
        //     console.log(test[j], code.length, code);
        // }
        // return;

        doneCallback(code)
      } catch (ex) {
        doneCallback(null, ex)
      }
    }

    i.onerror = function() {
      doneCallback(null, new Error('image onerror callback'))
    }

    // Start loading.
    i.src = src
  }

  /**
   * Async method for converting gif image to base64 string.
   * In case it is not gif - this method will fallback to staticImage2Base64.
   * @param {String} src File url.
   * @param {function(?base64:string, error=:Object)} doneCallback Result callback.
   */
  var gif2Base64 = function(src, doneCallback) {
    var xhr = new XMLHttpRequest()
    xhr.open('GET', src)
    xhr.responseType = 'blob'

    xhr.onload = function() {
      var blob = xhr.response

      if (blob.type !== 'image/gif') {
        console.log(
          'gif2Base64: expected mimeType to be image/gif but got',
          blob.type,
          'instead. Fallback to staticImage2Base64'
        )
        staticImage2Base64(noCacheUrl(src), doneCallback)
        return
      }

      var myReader = new FileReader()
      myReader.readAsDataURL(blob)

      myReader.addEventListener('loadend', function(evt) {
        var size =
          event.target && event.target.result && event.target.result.length
            ? event.target.result.length
            : 0

        if (size / (1024 * 1024) < MAX_GIF_SIZE) {
          doneCallback(evt.target.result)
        } else {
          doneCallback(src)
        }
      })

      myReader.addEventListener('onabort', function() {
        doneCallback(
          null,
          'gif2Base64 error: ArrayBuffer to base64 convertion aborted'
        )
      })

      myReader.addEventListener('onerror', function() {
        doneCallback(
          null,
          'gif2Base64 error: ArrayBuffer to base64 convertion error'
        )
      })
    }

    xhr.onabort = function() {
      doneCallback(null, 'gif2Base64 download error: aborted')
    }

    xhr.onerror = function() {
      doneCallback(null, 'gif2Base64 download error: error')
    }

    xhr.ontimeout = function() {
      doneCallback(null, 'gif2Base64 download error: timeout')
    }

    xhr.send()
  }

  var createAndReturnBase64 = function(src, id, sendResponse) {
    var doneCallback = function(base64, error) {
      if (base64) {
        sendResponse({ type: 'image', id: id, base64: base64 })
      } else {
        sendResponse({ type: 'image', id: id, error: true })
        console.log('createAndReturnBase64 error', error)
      }
    }

    getMimeType(src, function(mimeType, error) {
      if (error) {
        console.log(error)
        gif2Base64(src, doneCallback)
      } else if (mimeType === 'image/gif') {
        gif2Base64(src, doneCallback)
      } else {
        staticImage2Base64(src, doneCallback)
      }
    })
  }

  var saveToRIL = function(_data, settings) {
    var articleBody = _data.data
    var title = _data.title
    var url = _data.url
    _data.data = ''
    _data.user = settings.user

    var isIntranet =
      s.has(url, 'yandex-team.') ||
      (s.has(url, 'localhost') && !s.has(url, '/public/'))

    // FIXME setup new public ril server
    var ril_host = isIntranet ? config.hosts.intranet : config.hosts._default
    // var ril_host = config.hosts.intranet;

    // Send in chunks.
    // var chunkSize = 500 * 1024;
    // NOTE в какой-то момент и 500 стало много
    var chunkSize = 100 * 1024

    var sendChunk = function(when, index) {
      var data = $.extend({}, _data, {
        data: articleBody.substr(index, chunkSize),
        lastChunk: index + chunkSize >= articleBody.length,
      })

      var send_ = function() {
        return $.ajax({
          url: ril_host + '/save',
          type: 'POST',
          dataType: 'json',
          data: data,
          timeout: 60000,
        })
      }

      if (!when) {
        return send_()
      }

      var promise = new $.Deferred()
      when.done(function() {
        var request = send_()
        request.done(function(data) {
          promise.resolve(data)
        })
        request.fail(function() {
          promise.reject()
        })
      })
      when.fail(function() {
        promise.reject()
      })
      return promise
    }

    var index = 0
    var promise = null
    while (index < articleBody.length) {
      promise = sendChunk(promise, index)
      index += chunkSize
    }

    promise.done(function() {
      // Add item to ril log file (now it is here: ~/Dropbox/ril.txt
      $.ajax({
        url: 'http://localhost:8130',
        type: 'GET',
        dataType: 'text',
        data: {
          action: 'ril-log',
          url: url,
          title: title,
        },
      })

      // Close tab after save.
      chrome.tabs.remove(tabs[url])
    })

    promise.fail(function() {
      alert('Could not save article')
      console.log('FAIL', arguments)
    })
  }

  chrome.extension.onConnect.addListener(function(port) {
    port.onMessage.addListener(function(message, port) {
      if (message.type === 'image') {
        createAndReturnBase64(message.src, message.id, function(msg) {
          port.postMessage(msg)
        })
      } else if (message.type === 'save') {
        getSettings((settings) => {
          saveToRIL(message.data, settings)
        })
      } else {
        alert('UNKNOWN MESSAGE')
      }
    })
  })

  function initButton() {
    chrome.browserAction.onClicked.addListener(function(tab) {
      tabs[tab.url] = tab.id
      // chrome.tabs.executeScript(tab.id, { file: 'instapaper.js' });
      chrome.tabs.executeScript(tab.id, { file: 'dist/instapaper.js' })
    })
  }

  $(initButton)

  // createAndReturnBase64('http://www.mindcollapse.com/static/media/blog/asia/sg_nightview.jpg');
  // createAndReturnBase64('http://img-fotki.yandex.ru/get/2714/120577698.1/0_66c72_5781ac66_XXL');
})()
